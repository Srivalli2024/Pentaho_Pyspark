import pandas as pd
import json
import openai
import os
import shutil
import xml.etree.ElementTree as ET
from flask import Flask, render_template, request, send_file
from github import Github
import requests
import logging
from logging.handlers import RotatingFileHandler

app = Flask(__name__)
app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'

# Configure logging with a rotating log file handler
log_filename = 'app.log'
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
handler = RotatingFileHandler(log_filename, maxBytes=10*1024*1024, backupCount=1)
handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
logger = logging.getLogger(__name__)
logger.addHandler(handler)

file_path = None
folder_name = None

def get_elements_from_file(xml_file_path, element_name):
    root = ET.parse(xml_file_path).getroot()
    step_elements = root.findall(f'.//{element_name}')
    return [ET.tostring(step, encoding='unicode') for step in step_elements] if step_elements else []

def save_elements_to_file(input_filename, output_filename):
    xml_file_path = f'{input_filename}'
    output_text_file_path = f'{output_filename}s.txt' if output_filename == 'step' else 'hop_order.txt'
    step_data_strings = get_elements_from_file(xml_file_path, output_filename)

    logger.info(f"{output_filename} elements extracted")

    with open(output_text_file_path, 'w', encoding='utf-8') as output_file:
        output_file.writelines(f"{step_data_string}\n" for step_data_string in step_data_strings)

    logger.info(f"The output has been saved to '{output_text_file_path}'")
    print(f"The output has been saved to '{output_text_file_path}'")

def openai_sequence_steps(hop_order_file_path, steps_file_path):
    # Read the configuration file for OpenAI credentials
    with open('config_file.json') as f:
        json_data = json.load(f)

    # Set up OpenAI configuration with the loaded credentials
    openai.api_type = json_data["openai_api_type"]
    openai.api_base = json_data["openai_api_base"]
    openai.api_version = json_data["openai_api_version"]
    openai.api_key = json_data['openai_api_key']
  
    # Read the contents of the steps file
    with open(hop_order_file_path, 'r', encoding='utf-8') as file:
        hop_order = file.read()
        
    # Read the contents of the steps file
    with open(steps_file_path, 'r', encoding='utf-8') as file:
        steps = file.read()
  
    try:
        # Make the API call to OpenAI with the hop info and the contents of steps.txt
        response = openai.ChatCompletion.create(
            engine="gpt-4-32k",
            temperature=0.1,
            messages=[
                {
                    "role": "system",
                    "content": "You are an expert in converting Pentaho code to Spark code.\n\nYou will receive a hop order file and a steps file. Analyze the hop order to determine the sequence, then convert the corresponding steps into Spark code following that sequence.\n\nReturn the Spark code for the entire flow step by step as per the steps file.\n\nGive sequence number to each step."
                },
                {   "role": "user", 
                    "content": f"Here is the Pentaho hop order file: {hop_order} and the steps file {steps}"
                }
            ],
        )
      
        # Extract the output from the response
        output = response["choices"][0]["message"]["content"]
        return output
    except Exception as e:
        print(e)
        logger.error(f"{e}")
        raise

def copy_specific_files(source_folder, target_folder, file_names):
    if not os.path.exists(target_folder):
        os.makedirs(target_folder)
    
    for file_name in file_names:
        source_path = os.path.join(source_folder, file_name)
        target_path = os.path.join(target_folder, file_name)
        if os.path.exists(source_path):
            shutil.copy(source_path, target_path)
            print(f"Copied '{file_name}' to '{target_folder}'.")
        else:
            print(f"File '{file_name}' not found in '{source_folder}'.")

repo_owner = 'Srivalli2024'
repo_name = 'Pentaho_Pyspark'

@app.route('/')
def index():
    g = Github()
    repo = g.get_user(repo_owner).get_repo(repo_name)
    files = [file.name for file in repo.get_contents('') if file.type == 'file']
    return render_template('index.html', files=files)

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    global file_path, folder_name
    if request.method == 'POST':
        repo_owner = 'Srivalli2024'
        repo_name = 'Pentaho_Pyspark'
        local_folder = 'uploads'
        url = f'https://api.github.com/repos/{repo_owner}/{repo_name}/contents/'
        response = requests.get(url)

        if response.status_code == 200:
            contents = response.json()
            for content in contents:
                if content['type'] == 'file' and content['name'].endswith('.ktr'):
                    raw_url = content['download_url']
                    file_content = requests.get(raw_url).content
                    with open(os.path.join(local_folder, content['name']), 'wb') as file:
                        file.write(file_content)
        else:
            print('Failed to retrieve repository contents')
        folder_path = 'uploads'
        file_names = os.listdir(folder_path)
        file_path = 'uploads/' + file_names[0]
        folder_name = os.path.splitext(file_names[0])[0]
        return render_template('upload.html', file_names=file_names)

    return render_template('upload.html')

@app.route('/result', methods=['GET', 'POST'])
def result():
    if request.method == 'POST':
        global file_path, folder_name
        input_filename = file_path
        folder_name = 'spark_code/' + folder_name
        hop_order_file_path = "hop_order.txt"
        steps_file_path = "steps.txt"
        output_file_path = "pyspark_code.txt"

        save_elements_to_file(input_filename, 'order')
        save_elements_to_file(input_filename, 'step')

        code_output = openai_sequence_steps(hop_order_file_path, steps_file_path)
        print(code_output)
    
        with open(output_file_path, 'a', encoding='utf-8') as output_file:
            output_file.write(code_output)

        source_folder = ""
        target_folder = folder_name
        file_names = ["hop_order.txt", "steps.txt", "pyspark_code.txt"]
        copy_specific_files(source_folder, target_folder, file_names)
        for file_name in file_names:
            file_path = os.path.join(source_folder, file_name)
            os.remove(file_path)
        logger.info(f"The converted code is saved in {folder_name} folder")

        folder_path = 'uploads'
        files = os.listdir(folder_path)
        for file_name in files:
            file_path = os.path.join(folder_path, file_name)
            os.remove(file_path)

        # Render a template to display the output
        return render_template('result.html', data=code_output)
    
    # Render the initial form
    return render_template('upload.html')

@app.route('/download', methods=['GET', 'POST'])
def download():
    # Check if the file exists
    if os.path.exists('pyspark_code.txt'):
        # Send the file to the user for download
        return send_file('pyspark_code.txt', as_attachment=True)
    else:
        # File not found, return an error message
        return "File not found"

if __name__ == '__main__':
    app.run(debug=True)